package cmp;

/**
 * Created by chenchuk on 11/10/17.
 */
public enum TokenType {
    keyword,
    symbol,
    identifier,
    integerConstant,
    stringConstant
}
